from .module1 import myFunc
from .module1 import mySum