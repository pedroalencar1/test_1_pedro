# READ ME

This is an example package.

Sourse: https://packaging.python.org/en/latest/tutorials/packaging-projects/