def myFunc():
    
    print("Hello World!")
    
def mySum(a,b):
    
    return a+b